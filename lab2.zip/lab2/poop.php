<?php echo"Welcome " .  $_GET["name"] . "<br>";
echo "Your email address is:  " . $_GET["email"]; ?>
